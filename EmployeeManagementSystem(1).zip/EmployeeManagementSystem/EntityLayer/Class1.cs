﻿using System;

namespace EntityLayer
{
    public class Class1
    {

    }
}
