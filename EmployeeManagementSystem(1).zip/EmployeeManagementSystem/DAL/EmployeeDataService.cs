﻿using System;
using System.Collections.Generic;
using System.Text;
using DAL.Models;
using EntityLayer;
using DAL;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace DAL
{
    public class EmployeeDataService :IEmployee
    {

        private EmployeeDatabaseContext db;

        public EmployeeDataService(EmployeeDatabaseContext db)
        {
            this.db = db;
        }

       
        public List<EmployeeDetailModel> DisplayAllEmployees()
        {
            List<EmployeeDetail> empList = new List<EmployeeDetail>();
            List<EmployeeDetailModel> empList2 = new List<EmployeeDetailModel>();
            
            try
            {
                empList = db.EmployeeDetails.ToList();                 
                foreach (var d in empList)
                {
                    EmployeeDetailModel e = new EmployeeDetailModel();
                    e.EmpId = d.EmpId;
                    e.FirstName = d.FirstName;
                    e.LastName = d.LastName;
                    e.State = d.State;
                    e.City = d.City;
                    e.Zip = d.Zip;
                    e.Moblie = d.Moblie;
                    e.DateofBirth = (DateTime)d.DateofBirth;
                    e.Email = d.Email;
                    empList2.Add(e);
                }
                return empList2;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public EmployeeDetailModel DeleteEmployee(int id)
        {
            EmployeeDetailModel? emp = new EmployeeDetailModel();
            EmployeeDetail? EmpRec;
            try
            {
                EmpRec = db.EmployeeDetails.Find(id);
                if (EmpRec != null)
                {
                    db.EmployeeDetails.Remove(EmpRec);
                    db.SaveChanges();
                    emp.EmpId = EmpRec.EmpId;
                    emp.FirstName = EmpRec.FirstName;
                    emp.LastName = EmpRec.LastName;
                    emp.State = EmpRec.State;
                    emp.City = EmpRec.City;
                    emp.Zip = EmpRec.Zip;
                   
                    return emp;
                }
                else
                {
                    throw new Exception("Employee Record not Found");
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        public EmployeeDetailModel EditEmployee(EmployeeDetailModel EmpRec)

            {
                EmployeeDetail rec = new EmployeeDetail();
                rec.EmpId = EmpRec.EmpId;
                rec.FirstName = EmpRec.FirstName;
                rec.LastName = EmpRec.LastName;
                rec.State = EmpRec.State;
                rec.City = EmpRec.City;
                rec.Zip = EmpRec.Zip;
                rec.Moblie = EmpRec.Moblie;
                rec.DateofBirth = (DateTime)EmpRec.DateofBirth;
                rec.Email = EmpRec.Email;
            
                try
                {
                    if (EmpRec != null)
                    {
                        db.Entry(rec).State = EntityState.Modified;
                        db.SaveChanges();
                        return EmpRec;
                    }
                    else
                    {
                        throw new Exception("Updation failed");
                    }
                }
                catch (Exception e)
                {
                    throw new Exception(e.Message);
                }
            }
        public EmployeeDetailModel AddEmploye(EmployeeDetailModel EmpRec)
        {
            EmployeeDetail rec = new EmployeeDetail();
            rec.EmpId = EmpRec.EmpId;
            rec.FirstName = EmpRec.FirstName;
            rec.LastName = EmpRec.LastName;
            rec.State = EmpRec.State;
            rec.City = EmpRec.City;
            rec.Zip = EmpRec.Zip;
            rec.Moblie = EmpRec.Moblie;
            rec.DateofBirth = (DateTime)EmpRec.DateofBirth;
            rec.Email = EmpRec.Email;
            
            
            try
            {
                db.EmployeeDetails.Add(rec);
                db.SaveChanges();
                return EmpRec;
            }
            catch (Exception e)
            {
                if (e.InnerException != null)
                {
                    throw new Exception(e.InnerException.Message);
                }
                throw new Exception(e.Message);
            }
        }
        public EmployeeDetailModel DisplayByEmpId(int id)
        {
            EmployeeDetailModel? emp = new EmployeeDetailModel();
            EmployeeDetail? EmpRec;
            try
            {
                EmpRec = db.EmployeeDetails.Find(id);
                if (EmpRec != null)
                {
                    emp.EmpId = EmpRec.EmpId;
                    emp.FirstName = EmpRec.FirstName;
                    emp.LastName = EmpRec.LastName;
                    emp.State = EmpRec.State;
                    emp.City = EmpRec.City;
                    emp.Zip = EmpRec.Zip;
                    emp.Moblie = EmpRec.Moblie;
                    emp.DateofBirth = (DateTime)EmpRec.DateofBirth;
                    emp.Email = EmpRec.Email;
                    return emp;
                }
                else
                {
                    throw new Exception("Employee Record not Found");
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }
    }
}

