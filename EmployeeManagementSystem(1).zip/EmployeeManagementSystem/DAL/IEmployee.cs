﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using EntityLayer;
using DAL;

namespace DAL
{
   public  interface IEmployee
    {
        public List<EmployeeDetailModel> DisplayAllEmployees();
        public EmployeeDetailModel DeleteEmployee(int id);
        public EmployeeDetailModel EditEmployee(EmployeeDetailModel EmpRec);
        public EmployeeDetailModel AddEmploye(EmployeeDetailModel EmpRec);
        public EmployeeDetailModel DisplayByEmpId(int id);
    }
}
