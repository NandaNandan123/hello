﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using DAL;
using EntityLayer;

namespace UIL.Controllers
{
    public class EmployeeController : Controller
    {
        public IEmployee pser;
        public EmployeeController(IEmployee pser)
        {
            this.pser = pser;
        }

        //public EmployeeDataService pser = new EmployeeDataService();

        public IActionResult DisplayAllEmployees()
        {
            List<EmployeeDetailModel> plist;
            plist= pser.DisplayAllEmployees();
            return View(plist);
        }
        public IActionResult DisplayByEmpId(int id)
        {
            EmployeeDetailModel Rec = pser.DisplayByEmpId(id);

            return View(Rec);
        }
        public IActionResult AddEmployee()
        {
            return View();
        }
        [HttpPost]
        public IActionResult AddEmployee(EmployeeDetailModel NewRec)
        {
            pser.AddEmploye(NewRec);
            return RedirectToAction("DisplayAllEmployees");
        }
        public IActionResult EditEmployee(int id)
        {
            EmployeeDetailModel rec = pser.DisplayByEmpId(id);
            return View(rec);
        }
        [HttpPost]
        public IActionResult EditEmployee(EmployeeDetailModel updRec)
        {
            pser.EditEmployee(updRec);
            return RedirectToAction("DisplayAllEmployees");
        }

        public IActionResult DeleteEmployee(int id)
        {
            pser.DeleteEmployee(id);
            return RedirectToAction("DisplayAllEmployees");
        }

    }
}
