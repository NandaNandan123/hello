﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibrary2
{
    public class UserEntity
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }
    }
}
