﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ClassLibrary1;
using ClassLibrary2;
using ClassLibrary1.Models;
using Temparature_check;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace Temparature_check.Controllers
{
    [ApiController]
    public class SecurityWebApiController : ControllerBase
    {
        private IUser Uservice;
        public SecurityWebApiController(IUser Uservice)
        {
            this.Uservice = Uservice;
        }
        [HttpPost("ValidateUser")]
        public IActionResult ValidateUser(UserModel user)
        {
            TokenDetail tdel = new TokenDetail();
            if (user.UserName == "Nandan" && user.Password == "Nandan")
            {
                var token = CreateToken(user.Role); tdel.UserName = user.UserName;
                tdel.Role = user.Role;
                tdel.Token = token; return Ok(tdel);
            }
            else
            {
                return BadRequest("Invalid Credentials");
            }
        }
        private string CreateToken(string role)
        {
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("abcdefghijklmnopqrst"));
            var CredentialInfo = new SigningCredentials(key, SecurityAlgorithms.HmacSha256); 
            var clm = new List<Claim>(); 
            clm.Add(new Claim(ClaimTypes.Role, role));
            var token = new JwtSecurityToken(
            issuer: "http://localhost:15070",
            audience: "http://localhost:15070",
            expires: DateTime.Now.AddDays(5),
            claims: clm,
            signingCredentials: CredentialInfo);
            return new JwtSecurityTokenHandler().WriteToken(token);
        }
        [HttpPost("ValidateUser2")]
        public IActionResult ValidateUser2(UserEntity user)
        {
            TokenDetail tdel = new TokenDetail();
            var userData = Uservice.GetValidUser(user);
            if (userData != null)
            {
                var token = CreateToken(userData.Role); tdel.UserName = user.UserName;
                tdel.Role = user.Role;
                tdel.Token = token; return Ok(tdel);
            }
            else
            {
                return BadRequest("Invalid Credentials");
            }
        }
    }
}
