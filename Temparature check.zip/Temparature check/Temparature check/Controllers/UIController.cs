﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using ClassLibrary2;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace Temparature_check.Controllers
{
    public class UIController : Controller
    {
        private HttpClient Client; 
        public UIController()
        {
            Client = new HttpClient();
            Client.BaseAddress = new Uri("http://localhost:15070/");
        }
        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(UserEntity user)
        {
            TokenDetail tokenDtl; try
            {
                var res = Client.PostAsJsonAsync("ValidateUser2", user).Result;
                if (res.IsSuccessStatusCode)
                {
                    var data = res.Content.ReadAsStringAsync().Result;
                    tokenDtl = JsonConvert.DeserializeObject<TokenDetail>(data); SaveToken(tokenDtl.Token); return RedirectToAction("ShowWeatherReport", "UI");
                }
            }
            catch (Exception ex)
            {
                TempData["err"] = ex.Message;
            }
            return View();
        }
        private void SaveToken(string token)
        {
            HttpContext.Response.Cookies.Append("Jwt", token);
            HttpContext.Session.SetString("Jwt", token);
        }
        public IActionResult ShowWeatherReport()
        {
            string jwt = null;
            TempData["Error"] = "";
            if (Request.Cookies["Jwt"] != null)
            {
                jwt = Request.Cookies["Jwt"].ToString();
            }
            IEnumerable<WeatherForecast> report; try
            {
                Client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", jwt);
                var res = Client.GetAsync("GetWeatherForecast").Result;
                if (res.IsSuccessStatusCode)
                {
                    var data = res.Content.ReadAsStringAsync().Result;
                    report = JsonConvert.DeserializeObject<IEnumerable<WeatherForecast>>(data);
                    return View(report);
                }
                else if (res.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                {
                    throw new Exception("unauthroised user");
                }
                else
                {
                    throw new Exception("Server Error");
                }
            }
            catch (Exception ex)
            {
                TempData["Error"] = ex.Message;
            }
            return View(null);
        }
  
    }
}
