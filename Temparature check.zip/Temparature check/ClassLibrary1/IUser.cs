﻿using System;
using System.Collections.Generic;
using System.Text;
using ClassLibrary2;
namespace ClassLibrary1
{
    public interface IUser
    {
        IEnumerable<UserEntity> GetAllUsers();
        UserEntity GetUserByName(string name);
        UserEntity GetValidUser(UserEntity user);
        UserEntity RegisterUser(UserEntity NewUsr);
    }
}
