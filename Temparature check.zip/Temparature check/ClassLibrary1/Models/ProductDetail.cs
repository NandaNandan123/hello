﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ClassLibrary1.Models
{
    public partial class ProductDetail
    {
        public ProductDetail()
        {
            OrderDetails = new HashSet<OrderDetail>();
        }

        public int Pid { get; set; }
        public string Pname { get; set; }
        public int? Cost { get; set; }

        public virtual ICollection<OrderDetail> OrderDetails { get; set; }
    }
}
