﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ClassLibrary1.Models
{
    public partial class OrderDetail
    {
        public int OrderId { get; set; }
        public string Ordername { get; set; }
        public int? ProductId { get; set; }
        public int? Qty { get; set; }

        public virtual ProductDetail Product { get; set; }
    }
}
