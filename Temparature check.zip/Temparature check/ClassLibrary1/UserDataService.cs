﻿using System;
using System.Collections.Generic;
using System.Text;
using ClassLibrary2;
using ClassLibrary1;
using ClassLibrary1.Models;
using System.Linq;

namespace ClassLibrary1
{
    public class UserDataService : IUser
    {
        private OnlineStoreDbContext db;
        public UserDataService(OnlineStoreDbContext db)
        {
            this.db = db;
        }
        public IEnumerable<UserEntity> GetAllUsers()
        {
            throw new NotImplementedException();
        }
        public UserEntity GetUserByName(string name)
        {
            throw new NotImplementedException();
        }
        public UserEntity GetValidUser(UserEntity user)
        {
            UserEntity udet = new UserEntity();
            try
            {
                var validuser = db.UserDetails.Where(c => c.UserName == user.UserName && c.Password == user.Password).SingleOrDefault();
                if (validuser != null)
                {
                    udet.UserName = validuser.UserName;
                    udet.Password = validuser.Password;
                    udet.Role = validuser.Role;
                    return udet;
                }
                else
                {
                    throw new Exception("Invalid Username or Password");
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }
        public UserEntity RegisterUser(UserEntity NewUsr)
        {
            UserDetail NewRec = new UserDetail();
            NewRec.UserName = NewUsr.UserName;
            NewRec.Password = NewUsr.Password;
            NewRec.Role = NewUsr.Role; try
            {
                db.UserDetails.Add(NewRec);
                int status = db.SaveChanges(); if (status > 0)
                {
                    return NewUsr;
                }
                else
                {
                    throw new Exception("Insertion failed");
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }
    }
}
